package com.hackai.theartificials.smartbrowser.model.eventbus

import com.hackai.theartificials.smartbrowser.model.api.SearchResult

data class ClickEvent(val searchResult: SearchResult)