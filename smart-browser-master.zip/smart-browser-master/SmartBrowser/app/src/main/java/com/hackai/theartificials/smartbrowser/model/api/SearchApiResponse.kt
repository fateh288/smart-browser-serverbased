package com.hackai.theartificials.smartbrowser.model.api

data class SearchApiResponse(
    val success: Boolean = false,
    val results: List<SearchResult>
)