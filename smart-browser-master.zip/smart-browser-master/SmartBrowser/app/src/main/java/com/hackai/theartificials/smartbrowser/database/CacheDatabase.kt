package com.hackai.theartificials.smartbrowser.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.hackai.theartificials.smartbrowser.database.dao.MarkCacheDao
import com.hackai.theartificials.smartbrowser.database.entity.MarkCache

@Database(entities = [MarkCache::class], version = 1)
@TypeConverters(RoomTypeConverters::class)
abstract class CacheDatabase : RoomDatabase() {
    companion object {
        @Volatile
        private var INSTANCE: CacheDatabase? = null

        fun getDatabase(context: Context): CacheDatabase {
            val tempInstance = INSTANCE
            tempInstance?.let {
                return it
            } ?: run {
                synchronized(this) {
                    val instance = Room.databaseBuilder(
                        context.applicationContext, CacheDatabase::class.java,
                        "smart-browser.db"
                    ).build()
                    INSTANCE = instance
                    return instance
                }
            }
        }
    }

    abstract fun cacheDao(): MarkCacheDao
}