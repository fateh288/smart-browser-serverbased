import traceback
from itertools import chain

import simplejson
from html_parser_utils import url_to_html_dict
from html_parser_utils import html_mark_indexes_in_url, reset_html_dict
import numpy as np
import nltk
import re
from nltk.corpus import stopwords
import scipy

nltk.download('punkt')
nltk.download('stopwords')

unique_sentences = []
COSINE_DIST_THRESH = 84


def load_glove_model(glove_file):
    print("Loading Glove Model")
    with open(glove_file, encoding="utf8") as f:
        content = f.readlines()
    glove_model = {}
    for line in content:
        split_line = line.split()
        word = split_line[0]
        embedding = np.array([float(val) for val in split_line[1:]])
        glove_model[word] = embedding
    print("Done.", len(glove_model), " words loaded!")
    return glove_model


def preprocess(raw_text):
    # keep only words
    letters_only_text = re.sub("[^a-zA-Z]", " ", raw_text)

    # convert to lower case and split
    words = letters_only_text.lower().split()

    # remove stopwords
    stopwords_set = set(stopwords.words("english"))
    cleaned_words = list(set([w for w in words if w not in stopwords_set]))

    return cleaned_words


def preprocessing(url):
    print('new url: ', url)

    global unique_sentences

    paragraphs_url2 = [paragraph.get_text() for paragraph in url_to_html_dict(url)]

    sentences_url2 = [nltk.sent_tokenize(para) for para in paragraphs_url2]

    print('finding unique in ', url)

    highlight_url2 = []
    unique_sen_in_url2 = []

    for pid in range(len(sentences_url2)):
        for sid in range(len(sentences_url2[pid])):
            s1 = sentences_url2[pid][sid]
            found = False
            for s2 in unique_sentences[:]:
                score = cosine_distance_word_embedding_method(s1, s2)
                if score > COSINE_DIST_THRESH:  # similar
                    #print('found duplicate:', s2, '\n')
                    found = True
                    # unique_sentences.remove(s2)
                    break
            if not found:
                #print('found unique: [', pid, ': ', sid, ']', s1, '\n')
                unique_sen_in_url2.append(s1)
                highlight_url2.append([pid, sid])

    unique_sentences.extend(unique_sen_in_url2)

    #print('unique sentences after url: ', unique_sentences, '\n')

    results = []
    positions = {}

    for item in highlight_url2:
        try:
            if item[0] not in positions:
                positions[item[0]] = []
            char_pos = html_mark_indexes_in_url(url, item[0], sentences_url2[item[0]][item[1]])
            positions[item[0]].extend(char_pos)
        except Exception as e:
            print('parse exc: ', str(e))
            print(traceback.format_exc())

    for key, value in positions.items():
        if len(value) == 0:
            continue
        resp = {
            "tagName": "p",
            "tagPos": int(key),
            "positions": [list(map(int, pos)) for pos in value]
        }
        json = simplejson.dumps(resp)
        results.append(json)

    return results


# noinspection PyUnresolvedReferences
def cosine_distance_word_embedding_method(s1, s2):
    cosine = 1
    word_list1 = []
    word_list2 = []
    for word in preprocess(s1):
        try:
            word_list1.append(model[word])
        except KeyError as e:
            print('key error:', str(e))
    for word in preprocess(s2):
        try:
            word_list2.append(model[word])
        except KeyError as e:
            print('key error:', str(e))
        vector_1 = np.mean(word_list1, axis=0)
        vector_2 = np.mean(word_list2, axis=0)
        cosine = scipy.spatial.distance.cosine(vector_1, vector_2)

    return round((1 - cosine) * 100, 2)


def markup_url(url):
    results = []
    url_list.append(url)

    if len(url_list) == 1:
        paragraphs_url1 = [paragraph.get_text() for paragraph in url_to_html_dict(url_list[0])]
        global unique_sentences
        unique_sentences = list(chain.from_iterable([nltk.sent_tokenize(para) for para in paragraphs_url1]))
        print('unique sentences init: ', unique_sentences, '\n')
        return results
    else:
        results = preprocessing(url)
    return results


def reset():
    global url_list
    global unique_sentences
    url_list = []
    unique_sentences = []
    reset_html_dict()


url_list = []

model = load_glove_model("gloveFile.txt")


def main():
    url_list_l = ['http://127.0.0.1:5000/static/p1.html', 'http://127.0.0.1:5000/static/p2.html',
                  'http://127.0.0.1:5000/static/p3.html']
    locations1 = markup_url(url_list_l[0])
    locations2 = markup_url(url_list_l[1])
    locations3 = markup_url(url_list_l[2])
    print(locations1, locations2, locations3)
    # reset()
    # locations1 = markup_url(url_list_l[0])
    # print(locations1)


if __name__ == '__main__':
    main()
