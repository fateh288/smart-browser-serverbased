package com.hackai.theartificials.smartbrowser.model.api

data class MarkApiResponse(
    val success: Boolean = false,
    val locations: List<String>
)