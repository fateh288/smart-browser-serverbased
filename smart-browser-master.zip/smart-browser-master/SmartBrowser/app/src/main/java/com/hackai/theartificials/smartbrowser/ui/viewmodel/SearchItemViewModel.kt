package com.hackai.theartificials.smartbrowser.ui.viewmodel

import androidx.lifecycle.ViewModel
import com.hackai.theartificials.smartbrowser.model.api.SearchResult
import com.hackai.theartificials.smartbrowser.model.eventbus.ClickEvent
import org.greenrobot.eventbus.EventBus

class SearchItemViewModel(val searchResult: SearchResult) : ViewModel() {
    fun clickUrl() = EventBus.getDefault().post(ClickEvent(searchResult))
}