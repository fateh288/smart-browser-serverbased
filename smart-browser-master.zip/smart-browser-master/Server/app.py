from flask import Flask, request, send_from_directory
import simplejson
from search import perform_search
from trial import markup_url
from trial import reset
import os

app = Flask(__name__, static_url_path='')

static_path = "static"


@app.route('/search', methods=['GET'])
def query_for():
    query = request.args.get('query')
    reset()
    if query == "smart browser":
        results = []
        files = [f for f in os.listdir(static_path)]
        for f in files:
            search_result = {
                "title": f,
                "url": "http://192.168.1.209:5000/static/"+f
            }
            results.append(search_result)
        resp = {
            "success": True,
            "results": results
        }
        return simplejson.dumps(resp)
    else:
        return perform_search(query)


@app.route('/static/<path:path>')
def send_static(path):
    return send_from_directory('static', path)


@app.route('/highlight', methods=['GET'])
def highlight_text():
    url = request.args.get('url')
    locations = markup_url(url)
    if len(locations) == 0:
        resp = {
            "success": True,
            "locations": []
        }
    else:
        resp = {
            "success": True,
            "locations": locations
        }
    json = simplejson.dumps(resp)
    print('api resp: \n')
    print(json)
    return json


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)
