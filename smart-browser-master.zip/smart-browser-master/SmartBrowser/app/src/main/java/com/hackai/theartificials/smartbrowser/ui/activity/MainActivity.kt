package com.hackai.theartificials.smartbrowser.ui.activity

import android.app.SearchManager
import android.content.Intent
import android.os.Bundle
import android.provider.SearchRecentSuggestions
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.DefaultItemAnimator
import com.hackai.theartificials.smartbrowser.R
import com.hackai.theartificials.smartbrowser.data.EXTRA_URL
import com.hackai.theartificials.smartbrowser.databinding.ActivityMainBinding
import com.hackai.theartificials.smartbrowser.model.eventbus.ClickEvent
import com.hackai.theartificials.smartbrowser.database.DbRepository
import com.hackai.theartificials.smartbrowser.model.eventbus.ErrorEvent
import com.hackai.theartificials.smartbrowser.ui.adapter.SearchResultAdapter
import com.hackai.theartificials.smartbrowser.ui.custom.MySuggestionProvider
import com.hackai.theartificials.smartbrowser.ui.viewmodel.SearchViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import splitties.systemservices.searchManager
import splitties.toast.toast
import java.net.ConnectException
import java.net.SocketTimeoutException

class MainActivity : AppCompatActivity() {
    companion object {
        private val TAG = "${MainActivity::class.java.simpleName}log"
    }

    private lateinit var binding: ActivityMainBinding

    private val viewModel by lazy {
        ViewModelProvider(this).get(SearchViewModel::class.java)
    }
    private val searchResultAdapter by lazy { SearchResultAdapter(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main)
        setSupportActionBar(binding.toolBar)
        supportActionBar?.apply {
            setDisplayShowHomeEnabled(true)
            setDisplayShowCustomEnabled(true)
            setDisplayShowTitleEnabled(false)
            setDisplayUseLogoEnabled(true)
            setLogo(R.drawable.app_icon)
        }

        initSwipeRefresh()
        initRecyclerView()

        viewModel.searchLiveData.observe(this, Observer {
            Log.d(TAG, "onCreate: search results found: ${it.size}")
            searchResultAdapter.submitList(it) {
                binding.swipeRefresh.isRefreshing = false
            }
        })
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (Intent.ACTION_SEARCH == intent.action) {
            lifecycleScope.launch(Dispatchers.IO) { DbRepository.getInstance().clearCache() }
            intent.getStringExtra(SearchManager.QUERY)?.also { query ->
                SearchRecentSuggestions(
                    this,
                    MySuggestionProvider.AUTHORITY,
                    MySuggestionProvider.MODE
                )
                    .saveRecentQuery(query, null)
                binding.swipeRefresh.isRefreshing = true
                viewModel.searchFor(query)
            }
        }
        setIntent(intent)
    }

    override fun onDestroy() {
        super.onDestroy()
        binding.unbind()
    }

    override fun onResume() {
        super.onResume()
        EventBus.getDefault().register(this)
    }

    override fun onPause() {
        super.onPause()
        EventBus.getDefault().unregister(this)
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_search, menu)

        menu.findItem(R.id.action_search).apply {
            setActionView(R.layout.layout_search)
            actionView.findViewById<SearchView>(R.id.searchView).apply {
                setSearchableInfo(searchManager.getSearchableInfo(componentName))
                setIconifiedByDefault(false)
                setOnSuggestionListener(object : SearchView.OnSuggestionListener {
                    override fun onSuggestionSelect(position: Int) = true

                    override fun onSuggestionClick(position: Int): Boolean {
                        val cursor = suggestionsAdapter.cursor
                        cursor.moveToPosition(position)
                        val query = cursor.getString(2)
                        setQuery(query, true)
                        return true
                    }
                })
            }
        }
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.action_clear_history) {
            SearchRecentSuggestions(this, MySuggestionProvider.AUTHORITY, MySuggestionProvider.MODE)
                .clearHistory()
        }
        return true
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onClickEvent(clickEvent: ClickEvent) {
        val intent = Intent(this, WebViewActivity::class.java)
            .putExtra(EXTRA_URL, clickEvent.searchResult.url)
        startActivity(intent)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onErrorEvent(errorEvent: ErrorEvent) {
        val (t) = errorEvent
        toast(when (t) {
            is ConnectException -> "Connect to a Network!"
            is SocketTimeoutException -> "Connection timed out"
            else -> "Network error"
        })
        binding.swipeRefresh.isRefreshing = false
    }

    private fun initSwipeRefresh() {
        binding.swipeRefresh.apply {
            setColorSchemeResources(
                R.color.colorPrimary,
                R.color.colorAccent,
                R.color.colorPrimaryDark
            )
            setOnRefreshListener {
                isRefreshing = true
                val query = intent.getStringExtra(SearchManager.QUERY) ?: ""
                viewModel.searchFor(query)
            }
        }
    }

    private fun initRecyclerView() {
        binding.recyclerView.apply {
            adapter = searchResultAdapter
            itemAnimator = DefaultItemAnimator()
        }
    }
}