from urllib.request import urlopen
from bs4 import BeautifulSoup
import numpy as np
import bs4

url_html_dict = {}

def reset_html_dict():
    global url_html_dict
    url_html_dict = {}

def get_html_dict():
    return url_html_dict

def convert_soap_to_txt_list(html_content):
    string_contents = []
    for element in html_content:
        if (type(element) == bs4.element.Tag):
            string_contents.append(element.get_text())
        else:
            string_contents.append(str(element))
    return string_contents

def get_running_length_list(lst):
    lengthi=0
    running_len_mapping_end = []
    running_len_mapping_start = []
    for string in lst:
        running_len_mapping_end.append(lengthi+len(str(string)))
        running_len_mapping_start.append(lengthi)
        lengthi+=len(str(string))
    return (running_len_mapping_start,running_len_mapping_end)

def url_to_html_dict(url):
    global url_html_dict
    if url not in url_html_dict.keys():
        html = urlopen(url).read()
        soup = BeautifulSoup(html, 'lxml')
        parsed_html = soup.find_all('p')
        url_html_dict[url] = parsed_html
    return url_html_dict[url]

def get_string_index_html2str(html_str):
    if type(html_str) is not str:
        print("get_string_index_html2str : Invalid params")
        return None
    stack = []
    for index in np.arange(0, len(html_str), 1):
        if html_str[index] == '<':
            stack.append('<')
        elif html_str[index] == '>':
            stack.pop()
        elif len(stack)==0:
            return index
    return -1

def get_highlight_list_html2str(paragraph_content, html2str_start_index, html2str_end_index, initial_offset_first_element, num_chars_highlight_index_first, num_chars_highlight_index_last, string_to_find):
    #print(num_chars_highlight_index_first," ",num_chars_highlight_index_last)
    (running_len_html_begin_list, running_len_html_end_list) = get_running_length_list(paragraph_content)
    list_highlight = []
    # TODO Optimize - first -> middle tags as one element -> last
    if html2str_start_index==html2str_end_index:
        offset = initial_offset_first_element
        if type(paragraph_content[html2str_start_index]) == bs4.element.Tag:
            offset = get_string_index_html2str(str(paragraph_content[html2str_start_index])) + initial_offset_first_element
        # print("offset=", offset)
        list_highlight.append([running_len_html_begin_list[html2str_start_index] + offset,
                               running_len_html_begin_list[html2str_start_index] + offset +len(string_to_find)])
        return list_highlight

    for index in np.arange(html2str_start_index, html2str_end_index + 1, 1):
        if index == html2str_start_index:
            offset = initial_offset_first_element
            if type(paragraph_content[index]) == bs4.element.Tag:
                offset = get_string_index_html2str(str(paragraph_content[index])) + initial_offset_first_element
            #print("offset=", offset)
            list_highlight.append([running_len_html_begin_list[html2str_start_index] + offset,
                                   running_len_html_begin_list[html2str_start_index] + offset + num_chars_highlight_index_first])
        elif index == html2str_end_index:
            offset = 0
            if type(paragraph_content[index]) == bs4.element.Tag:
                offset = get_string_index_html2str(str(paragraph_content[index]))
            #print("offset=", offset)
            list_highlight.append([running_len_html_begin_list[html2str_end_index] + offset,
                                   running_len_html_begin_list[html2str_end_index] + offset + num_chars_highlight_index_last])
        else:
            list_highlight.append([running_len_html_begin_list[index], running_len_html_end_list[index]])
    #print(list_highlight)
    return list_highlight

def html_mark_indexes_in_url(url, paragraph_id, string_to_find):
    if url not in url_html_dict.keys():
        url_to_html_dict(url)
    html_element_list = url_to_html_dict(url)
    paragraph_content = html_element_list[paragraph_id].contents
    paragraph_content_html2str = convert_soap_to_txt_list(paragraph_content)
    paragraph_string = ''.join(paragraph_content_html2str)

    (running_len_html2txt_begin_list , running_len_html2txt_end_list) = get_running_length_list(paragraph_content_html2str)

    #start and end position of str in paragraph text
    str_start_index = paragraph_string.index(string_to_find)
    str_end_index = str_start_index + len(string_to_find)

    #index in list
    try:
        html2txt_start_index = running_len_html2txt_end_list.index(list(filter(lambda i: i > str_start_index, running_len_html2txt_end_list))[0])
    except IndexError as e:
        print("Exception:",e)
        html2txt_start_index = len(running_len_html2txt_end_list)-1
    html2txt_end_index = running_len_html2txt_end_list.index(list(filter(lambda i: i > str_end_index, running_len_html2txt_end_list))[0])

    #num chars to highlight
    num_chars_highlight_first_ele = running_len_html2txt_end_list[html2txt_start_index] - str_start_index
    num_chars_highlight_last_ele = str_end_index - running_len_html2txt_begin_list[html2txt_end_index]

    initial_offset_first_element = str_start_index - running_len_html2txt_begin_list[html2txt_start_index]

    highlight_list = get_highlight_list_html2str(paragraph_content, html2txt_start_index, html2txt_end_index,
                                                 initial_offset_first_element,num_chars_highlight_first_ele,
                                                 num_chars_highlight_last_ele, string_to_find)
    return highlight_list

# def main():
#     list_to_highlight = html_mark_indexes_in_url('https://en.wikipedia.org/wiki/Arrow_(TV_series)',1,"w is an American superhero television series developed")
#     print(list_to_highlight)
#
# if __name__ == '__main__':
#     main()


