package com.hackai.theartificials.smartbrowser.model.api

data class SearchResult(
    val title: String,
    val url: String
)