package com.hackai.theartificials.smartbrowser.server

import com.hackai.theartificials.smartbrowser.model.api.MarkApiResponse
import com.hackai.theartificials.smartbrowser.model.api.SearchApiResponse
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Query

interface RetrofitService {
    @GET("/highlight")
    suspend fun findUniqueText(@Query("url") url: String): Response<MarkApiResponse>

    @GET("/search")
    suspend fun searchFor(@Query("query") query: String): Response<SearchApiResponse>
}