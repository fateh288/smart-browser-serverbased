# smart-browser

A web browser app which shows search results for a query and highlights the unique information on each link based on the previously opened links in the search results.

## Setup

Run the app.py python script on your laptop to host a localhost server. Go to Constants.kt in the Android app code and change the base url IP address to your laptop IP address.
