package com.hackai.theartificials.smartbrowser.ui.activity

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.net.ConnectivityManager
import android.net.Network
import android.os.Build
import android.os.Bundle
import android.util.Base64
import android.util.Log
import android.view.MenuItem
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.lifecycleScope
import com.andruid.magic.customviews.ui.webview.ProgressWebChromeClient
import com.hackai.theartificials.smartbrowser.R
import com.hackai.theartificials.smartbrowser.data.EXTRA_URL
import com.hackai.theartificials.smartbrowser.database.DbRepository
import com.hackai.theartificials.smartbrowser.database.entity.MarkCache
import com.hackai.theartificials.smartbrowser.databinding.ActivityWebViewBinding
import com.hackai.theartificials.smartbrowser.model.api.MarkApiResponse
import com.hackai.theartificials.smartbrowser.server.NetworkRepository
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import splitties.systemservices.connectivityManager
import splitties.toast.toast
import java.io.InputStream
import java.net.ConnectException
import java.net.SocketTimeoutException

class WebViewActivity : AppCompatActivity() {
    companion object {
        private val TAG = "${WebViewActivity::class.java.simpleName}log"
    }

    private var pageLoaded = false

    private lateinit var binding: ActivityWebViewBinding
    private lateinit var apiResponse: MarkApiResponse

    private val coroutineExceptionHandler = CoroutineExceptionHandler { _, t ->
        t.printStackTrace()
        toast(
            when (t) {
                is ConnectException -> "Connect to a Network!"
                is SocketTimeoutException -> "Connection timed out"
                else -> "Network error"
            }
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            connectivityManager.registerDefaultNetworkCallback(object :
                ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    super.onAvailable(network)
                    toast("Retrying")
                    findUniqueText(this@WebViewActivity.intent.getStringExtra(EXTRA_URL) ?: "")
                }
            })
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_web_view)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        initWebView()
        with(binding) {
            swipeRefresh.setColorSchemeResources(
                R.color.colorPrimary, R.color.colorAccent,
                R.color.colorPrimaryDark
            )
            swipeRefresh.setOnRefreshListener {
                webView.webChromeClient = object : ProgressWebChromeClient(progressBar) {
                    override fun onProgressChanged(view: WebView?, newProgress: Int) {
                        super.onProgressChanged(view, newProgress)
                        Log.d(TAG, "onProgressChanged: $newProgress")
                        swipeRefresh.isRefreshing = (newProgress < 50)
                    }
                }
                swipeRefresh.isRefreshing = true
                webView.reload()
            }
            val url = intent.getStringExtra(EXTRA_URL) ?: ""
            webView.loadUrl(url)

            injectJS()
            findUniqueText(url)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        binding.unbind()
    }

    override fun onBackPressed() {
        if (binding.webView.canGoBack()) {
            binding.webView.goBack()
        } else
            super.onBackPressed()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home)
            finish()
        return true
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun initWebView() {
        with(binding) {
            webView.apply {
                settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    loadWithOverviewMode = true
                    useWideViewPort = true
                    setSupportZoom(true)
                    builtInZoomControls = true
                    displayZoomControls = false
                    userAgentString =
                        "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:40.0) Gecko/20100101 Firefox/40.1"

                    allowUniversalAccessFromFileURLs = true
                    allowFileAccessFromFileURLs = true
                }

                /*scrollBarStyle = WebView.SCROLLBARS_OUTSIDE_OVERLAY
                isScrollbarFadingEnabled = false*/

                webViewClient = object : WebViewClient() {
                    override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                        super.onPageStarted(view, url, favicon)
                        setTitle(url)
                    }

                    override fun onPageFinished(view: WebView?, url: String?) {
                        super.onPageFinished(view, url)
                        Log.d(TAG, "onPageFinished: loading js")
                        injectJS()
                        if (::apiResponse.isInitialized && view?.canGoBack() == false)
                            highlightUnique()
                        else
                            pageLoaded = true
                    }
                }
                Log.d(TAG, "initWebView: $isAttachedToWindow")
            }
        }
    }

    private fun injectJS() {
        try {
            val inputStream: InputStream = assets.open("highlight.js")
            val buffer = ByteArray(inputStream.available())
            inputStream.read(buffer)
            inputStream.close()
            val encoded: String = Base64.encodeToString(buffer, Base64.NO_WRAP)
            binding.webView.loadUrl(
                "javascript:(function() {" +
                        "var parent = document.getElementsByTagName('head').item(0);" +
                        "var script = document.createElement('script');" +
                        "script.type = 'text/javascript';" +
                        "script.innerHTML = window.atob('" + encoded + "');" +
                        "parent.appendChild(script)" +
                        "})()"
            )
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun highlightUnique() {
        apiResponse.apply {
            if (success) {
                locations.forEach { json ->
                    Log.d(TAG, "onPageFinished: json = $json")
                    binding.webView.evaluateJavascript("highlight($json);", null)
                }
            }
        }
    }

    private fun findUniqueText(url: String) {
        lifecycleScope.launch(Dispatchers.Main + coroutineExceptionHandler) {
            val markCache = DbRepository.getInstance().findMarkResponse(url)
            markCache?.let {
                Log.d(TAG, "onCreate: found in database")
                apiResponse = it.markApiResponse
            } ?: run {
                Log.d(TAG, "onCreate: sending request to server")
                val resp = withContext(Dispatchers.IO) {
                    NetworkRepository.getInstance().findUniqueText(url)
                }
                if (resp.isSuccessful) {
                    apiResponse = resp.body() ?: throw (Exception("Api response not received"))
                    launch(Dispatchers.IO) {
                        DbRepository.getInstance().insert(MarkCache(url, apiResponse))
                    }
                    if (pageLoaded)
                        highlightUnique()
                }
            }
        }
    }
}