package com.hackai.theartificials.smartbrowser.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.hackai.theartificials.smartbrowser.database.entity.MarkCache

@Dao
interface MarkCacheDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(cache: MarkCache)

    @Query("SELECT * FROM mark_cache WHERE url = :url")
    fun findMarkResponse(url: String): MarkCache?

    @Query("DELETE FROM mark_cache")
    fun clearCache()
}