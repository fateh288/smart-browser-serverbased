package com.hackai.theartificials.smartbrowser.server

import com.hackai.theartificials.smartbrowser.data.BASE_URL
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

object RetrofitClient {
    private lateinit var INSTANCE: Retrofit
    private val LOCK = Any()

    fun getRetrofitInstance(): Retrofit {
        synchronized(LOCK) {
            if (!::INSTANCE.isInitialized) {
                INSTANCE = Retrofit.Builder()
                    .baseUrl(BASE_URL)
                    .client(OkHttpClient.Builder()
                        .readTimeout(20, TimeUnit.MINUTES)
                        .build())
                    .addConverterFactory(GsonConverterFactory.create())
                    .build()
            }
        }
        return INSTANCE
    }
}