package com.hackai.theartificials.smartbrowser.data

const val BASE_URL = "http://192.168.0.105:5000/"

const val EXTRA_URL = "url"