function highlight(obj) {
  var tagName = obj.tagName
  var tagPos = obj.tagPos
  var positions = obj.positions
  var element = document.getElementsByTagName(tagName)[tagPos]
  var oldHtml = element.innerHTML
  var newHtml = ""
  var prev = [0, 0]
  positions.forEach((item) => {
    newHtml += oldHtml.substring(prev[1], item[0]) + '<mark>' + oldHtml.substring(item[0], item[1]) + '</mark>'
    prev = item
  })
  newHtml += oldHtml.substring(prev[1])
  element.innerHTML = newHtml
}