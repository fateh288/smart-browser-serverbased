function highlight(json) {
  var obj = JSON.parse(json)
  var tagName = obj.tagName
  var tagPos = obj.tagPos
  var positions = obj.positions
  alert(tagName + ":" + tagPos + ":" + positions.length)
  var element = document.getElementsByTagName(tagName)[tagPos]
  var oldHtml = element.innerHTML
  alert(oldHtml)
  var newHtml = ""
  var prev = [0, 0]
  positions.forEach((item) => {
    newHtml += oldHtml.substring(prev[1], item[0]) + '<mark>' + oldHtml.substring(item[0], item[1]) + '</mark>'
    prev = item
  });
  newHtml += oldHtml.substring(prev[1])
  element.innerHTML = newHtml
}

var json = '{"tagName": "p", "tagPos": 0, "positions": [[0, 2], [4, 6], [8, 10], [12, 14]]}'
highlight(json)
