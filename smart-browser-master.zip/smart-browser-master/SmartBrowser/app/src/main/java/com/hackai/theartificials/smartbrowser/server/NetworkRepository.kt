package com.hackai.theartificials.smartbrowser.server

import android.util.Log

class NetworkRepository {
    companion object {
        private val TAG = NetworkRepository::class.java.simpleName

        private var service: RetrofitService = RetrofitClient.getRetrofitInstance()
            .create(RetrofitService::class.java)

        private lateinit var INSTANCE: NetworkRepository

        fun getInstance(): NetworkRepository {
            if (!Companion::INSTANCE.isInitialized) {
                synchronized(this) {
                    Log.d(TAG, "Created news repository instance")
                    INSTANCE =
                        NetworkRepository()
                }
            }
            return INSTANCE
        }
    }

    suspend fun findUniqueText(url: String) = service.findUniqueText(url)

    suspend fun searchFor(query: String) = service.searchFor(query)
}