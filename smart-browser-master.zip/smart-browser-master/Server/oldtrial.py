# import simplejson
# from html_parser_utils import url_to_html_dict
# from html_parser_utils import html_mark_indexes_in_url, reset_html_dict
# import numpy as np
# import nltk
# import re
# from nltk.corpus import stopwords
# import scipy
#
# nltk.download('punkt')
# nltk.download('stopwords')
#
# unique_sentences = []
# COSINE_DIST_THRESH = 84
#
#
# def load_glove_model(glove_file):
#     print("Loading Glove Model")
#     with open(glove_file, encoding="utf8") as f:
#         content = f.readlines()
#     glove_model = {}
#     for line in content:
#         split_line = line.split()
#         word = split_line[0]
#         embedding = np.array([float(val) for val in split_line[1:]])
#         glove_model[word] = embedding
#     print("Done.", len(glove_model), " words loaded!")
#     return glove_model
#
#
# def preprocess(raw_text):
#     # keep only words
#     letters_only_text = re.sub("[^a-zA-Z]", " ", raw_text)
#
#     # convert to lower case and split
#     words = letters_only_text.lower().split()
#
#     # remove stopwords
#     stopwords_set = set(stopwords.words("english"))
#     cleaned_words = list(set([w for w in words if w not in stopwords_set]))
#
#     return cleaned_words
#
#
# def preprocessing(url):
#     print('new url: ', url)
#     global unique_sentences
#     unique_sentences_index = []
#     common_sentences_index = []
#
#     similar_list2_index = []
#     unsimilar_list2_index = []
#
#     # paragraphs_url1 = [paragraph.get_text() for paragraph in url_to_html_dict(url_list[0])]
#     paragraphs_url2 = [paragraph.get_text() for paragraph in url_to_html_dict(url)]
#
#     # global sentences_url1
#     # sentences_url1 = [nltk.sent_tokenize(para) for para in paragraphs_url1]
#
#     sentences_url2 = [nltk.sent_tokenize(para) for para in paragraphs_url2]
#
#     print('finding unique in ', url)
#
#     for i in range(len(unique_sentences)):
#         for j in range(len(unique_sentences[i])):
#             flag = 0
#             s1 = unique_sentences[i][j]
#             for k in range(len(sentences_url2)):
#                 for t in range(len(sentences_url2[k])):
#                     s2 = sentences_url2[k][t]
#                     g = cosine_distance_word_embedding_method(s1, s2)
#                     print('s1=', s1)
#                     print('s2=', s2)
#                     print('score=', g)
#                     if g > COSINE_DIST_THRESH:  # similar
#                         common_sentences_index.append(tuple([i, j]))
#                         similar_list2_index.append(tuple([k, t]))
#                         # print('Word Embedding method with a cosine distance asses that our two sentences are
#                         # similar to', g)
#                         flag = 1
#                         break
#                 if flag == 1:
#                     break
#
#     total_list_1 = []
#     for i in range(len(unique_sentences)):
#         for j in range(len(unique_sentences[i])):
#             total_list_1.append(tuple([i, j]))
#
#     for i in range(len(total_list_1)):
#         tuple_val = total_list_1[i]
#         res = tuple_val in common_sentences_index
#         res = str(res)
#         if res in ['False']:
#             unique_sentences_index.append(tuple_val)
#
#     total_list_2 = []
#     for i in range(len(sentences_url2)):
#         for j in range(len(sentences_url2[i])):
#             total_list_2.append(tuple([i, j]))
#
#     for i in range(len(total_list_2)):
#         tuple_val = total_list_2[i]
#         res = tuple_val in similar_list2_index
#         res = str(res)
#         if res in ['False']:
#             unsimilar_list2_index.append(tuple_val)
#
#     results = []
#     positions = {}
#
#     for item in unsimilar_list2_index:
#         try:
#             if item[0] not in positions:
#                 positions[item[0]] = []
#             char_pos = html_mark_indexes_in_url(url, item[0], sentences_url2[item[0]][item[1]])
#             positions[item[0]].extend(char_pos)
#         except Exception as e:
#             print('parse exc: ', str(e))
#
#     for key, value in positions.items():
#         if len(value) == 0:
#             continue
#         resp = {
#             "tagName": "p",
#             "tagPos": int(key),
#             "positions": [list(map(int, pos)) for pos in value]
#         }
#         json = simplejson.dumps(resp)
#         results.append(json)
#     #   print("similar_list2_index", sorted(similar_list2_index))
#     del_list_inplace(unique_sentences, list(dict.fromkeys(common_sentences_index)))
#     del_list_inplace(sentences_url2, list(dict.fromkeys(similar_list2_index)))
#     unique_sentences.extend(sentences_url2)
#
#     return results
#
#
# def del_list_inplace(lst, id_to_del):
#     #    print("len_of_list", len(lst))
#     for (i, j) in sorted(id_to_del, reverse=True):
#         #        print("index_to_delete", (i, j))
#         del (lst[i][j])
#
#
# # noinspection PyUnresolvedReferences
# def cosine_distance_word_embedding_method(s1, s2):
#     cosine = 1
#     try:
#         vector_1 = np.mean([model[word] for word in preprocess(s1)], axis=0)
#         vector_2 = np.mean([model[word] for word in preprocess(s2)], axis=0)
#         cosine = scipy.spatial.distance.cosine(vector_1, vector_2)
#     except KeyError as e:  # work on python 3.x
#         str(e)
#
#     return round((1 - cosine) * 100, 2)
#
#
# def markup_url(url):
#     results = []
#     # if same url is clicked ,need to return old saved responses
#     url_list.append(url)
#
#     if len(url_list) == 1:
#         paragraphs_url1 = [paragraph.get_text() for paragraph in url_to_html_dict(url_list[0])]
#         global unique_sentences
#         unique_sentences = [nltk.sent_tokenize(para) for para in paragraphs_url1]
#         return results
#     else:
#         results = preprocessing(url)
#     return results
#
#
# def reset():
#     global url_list
#     global unique_sentences
#     url_list = []
#     unique_sentences = []
#     reset_html_dict()
#
#
# url_list = []
#
# # import requests, zipfile, io
# # zip_file_url = 'http://nlp.stanford.edu/data/glove.6B.zip'
# # r = requests.get(zip_file_url)
# # z = zipfile.ZipFile(io.BytesIO(r.content))
# # z.extractall()
#
# model = load_glove_model("gloveFile.txt")
#
#
# def main():
#     url_list_l = ['http://127.0.0.1:5000/static/p1.html', 'http://127.0.0.1:5000/static/p2.html',
#                   'http://127.0.0.1:5000/static/p3.html']
#     locations1 = markup_url(url_list_l[0])
#     locations2 = markup_url(url_list_l[1])
#     locations3 = markup_url(url_list_l[2])
#     print(locations1, locations2, locations3)
#     reset()
#     locations1 = markup_url(url_list_l[2])
#     print(locations1)
#
#
# if __name__ == '__main__':
#     main()
