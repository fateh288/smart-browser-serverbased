package com.hackai.theartificials.smartbrowser.application

import android.app.Application
import com.hackai.theartificials.smartbrowser.database.DbRepository

class SmartBrowserApp : Application() {
    override fun onCreate() {
        super.onCreate()
        DbRepository.init(this)
    }
}