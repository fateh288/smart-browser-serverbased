package com.hackai.theartificials.smartbrowser.database.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.hackai.theartificials.smartbrowser.model.api.MarkApiResponse

@Entity(tableName = "mark_cache")
data class MarkCache(
    @PrimaryKey
    val url: String,
    val markApiResponse: MarkApiResponse
)