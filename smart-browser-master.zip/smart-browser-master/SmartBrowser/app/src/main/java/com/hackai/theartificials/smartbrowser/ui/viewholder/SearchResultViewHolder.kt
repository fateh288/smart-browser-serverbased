package com.hackai.theartificials.smartbrowser.ui.viewholder

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.hackai.theartificials.smartbrowser.R
import com.hackai.theartificials.smartbrowser.databinding.LayoutSearchResultBinding
import com.hackai.theartificials.smartbrowser.ui.viewmodel.SearchItemViewModel

class SearchResultViewHolder(private val binding: LayoutSearchResultBinding) :
    RecyclerView.ViewHolder(binding.root) {
    companion object {
        fun from(parent: ViewGroup): SearchResultViewHolder {
            val inflater = LayoutInflater.from(parent.context)
            val binding = DataBindingUtil.inflate<LayoutSearchResultBinding>(
                inflater, R.layout.layout_search_result,
                parent, false
            )
            return SearchResultViewHolder(binding)
        }
    }

    fun bind(viewModel: SearchItemViewModel) {
        binding.viewModel = viewModel
        binding.executePendingBindings()
    }
}