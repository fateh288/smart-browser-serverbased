import simplejson
from azure.cognitiveservices.search.websearch import WebSearchClient
from msrest.authentication import CognitiveServicesCredentials

# Replace with your subscription key.
key1 = '6fb64e870e364d7c9b1bbd001d0b5d03'
key2 = '11415487b86a4b249c355158cbf1731b'

subscription_key = key1

# noinspection PyTypeChecker
client = WebSearchClient(endpoint='https://api.cognitive.microsoft.com',
                         credentials=CognitiveServicesCredentials(subscription_key))


def perform_search(query):
    resp = {
        "success": False,
        "results": []
    }
    web_data = client.web.search(query)
    if hasattr(web_data.web_pages, 'value'):
        results = []
        for page in web_data.web_pages.value:
            search_result = {
                "title": page.name,
                "url": page.url
            }
            results.append(search_result)
        resp = {
            "success": True,
            "results": results
        }
    json = simplejson.dumps(resp)
    return json
