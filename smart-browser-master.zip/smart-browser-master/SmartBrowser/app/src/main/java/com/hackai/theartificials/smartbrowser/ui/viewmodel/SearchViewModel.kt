package com.hackai.theartificials.smartbrowser.ui.viewmodel

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Transformations
import androidx.lifecycle.ViewModel
import androidx.lifecycle.liveData
import com.hackai.theartificials.smartbrowser.model.api.SearchResult
import com.hackai.theartificials.smartbrowser.model.eventbus.ErrorEvent
import com.hackai.theartificials.smartbrowser.server.NetworkRepository
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.Dispatchers
import org.greenrobot.eventbus.EventBus

class SearchViewModel : ViewModel() {
    companion object {
        val TAG = "${SearchViewModel::class.java}log"
    }

    private val queryLiveData = MutableLiveData("")
    private val coroutineExceptionHandler = CoroutineExceptionHandler { _, t ->
        t.printStackTrace()
        EventBus.getDefault().post(ErrorEvent(t))
    }

    @Suppress("RemoveExplicitTypeArguments")
    val searchLiveData = Transformations.switchMap(queryLiveData) { query ->
        Log.d(TAG, "query changed: $query")
        liveData(Dispatchers.IO + coroutineExceptionHandler) {
            val list: List<SearchResult> = if (query.isNotBlank())
                NetworkRepository.getInstance().searchFor(query).body()?.results ?: emptyList()
            else
                emptyList<SearchResult>()
            emit(list)
        }
    }

    fun searchFor(query: String) {
        queryLiveData.postValue(query)
    }
}