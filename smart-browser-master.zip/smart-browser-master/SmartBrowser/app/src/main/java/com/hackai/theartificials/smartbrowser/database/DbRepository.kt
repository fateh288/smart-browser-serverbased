package com.hackai.theartificials.smartbrowser.database

import android.app.Application
import com.hackai.theartificials.smartbrowser.database.entity.MarkCache
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class DbRepository {
    companion object {
        private lateinit var database: CacheDatabase
        private lateinit var instance: DbRepository

        fun init(application: Application) {
            database = CacheDatabase.getDatabase(application.applicationContext)
            instance =
                DbRepository()
        }

        /**
         * Get static instance of this class
         * @return static instance of the repository
         */
        fun getInstance(): DbRepository {
            if (!Companion::instance.isInitialized)
                throw Exception("must call init() first in application class")
            return instance
        }
    }

    fun insert(cache: MarkCache) {
        database.cacheDao().insert(cache)
    }

    suspend fun findMarkResponse(url: String) = withContext(Dispatchers.IO) { database.cacheDao().findMarkResponse(url) }

    fun clearCache() {
        database.cacheDao().clearCache()
    }
}