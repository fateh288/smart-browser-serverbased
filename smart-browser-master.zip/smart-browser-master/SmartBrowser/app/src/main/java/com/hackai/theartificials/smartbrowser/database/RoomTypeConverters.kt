package com.hackai.theartificials.smartbrowser.database

import androidx.room.TypeConverter
import com.google.gson.Gson
import com.hackai.theartificials.smartbrowser.model.api.MarkApiResponse

object RoomTypeConverters {
    @JvmStatic
    @TypeConverter
    fun toString(markApiResponse: MarkApiResponse): String = Gson().toJson(markApiResponse)

    @JvmStatic
    @TypeConverter
    fun fromJson(json: String): MarkApiResponse = Gson().fromJson(json, MarkApiResponse::class.java)
}