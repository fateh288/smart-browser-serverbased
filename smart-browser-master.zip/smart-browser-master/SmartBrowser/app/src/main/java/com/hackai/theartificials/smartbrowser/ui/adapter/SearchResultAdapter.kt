package com.hackai.theartificials.smartbrowser.ui.adapter

import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import com.hackai.theartificials.smartbrowser.model.api.SearchResult
import com.hackai.theartificials.smartbrowser.ui.custom.BaseViewModelFactory
import com.hackai.theartificials.smartbrowser.ui.viewholder.SearchResultViewHolder
import com.hackai.theartificials.smartbrowser.ui.viewmodel.SearchItemViewModel

class SearchResultAdapter(private val activity: AppCompatActivity) :
    ListAdapter<SearchResult, SearchResultViewHolder>(SearchResultDiffCallback()) {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        SearchResultViewHolder.from(parent)

    override fun onBindViewHolder(holder: SearchResultViewHolder, position: Int) {
        val searchResult = getItem(position)
        searchResult?.let {
            val viewModel =
                ViewModelProvider(activity, BaseViewModelFactory { SearchItemViewModel(it) }).get(
                    it.title,
                    SearchItemViewModel::class.java
                )
            holder.bind(viewModel)
        }
    }
}

class SearchResultDiffCallback : DiffUtil.ItemCallback<SearchResult>() {
    override fun areItemsTheSame(oldItem: SearchResult, newItem: SearchResult) =
        oldItem.url == newItem.url

    override fun areContentsTheSame(oldItem: SearchResult, newItem: SearchResult) =
        oldItem == newItem
}