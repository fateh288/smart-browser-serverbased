package com.hackai.theartificials.smartbrowser.model.eventbus

data class ErrorEvent(val t: Throwable)